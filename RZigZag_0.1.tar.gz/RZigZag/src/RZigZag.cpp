// RZigZag.cpp : implements Zig-Zag with sub-sampling and control variates (ZZ-CV)
//
// Copyright (C) 2016 Joris Bierkens
//
// This file is part of RZigZag.
//
// RZigZag is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 2 of the License, or
// (at your option) any later version.
//
// RZigZag is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RZigZag.  If not, see <http://www.gnu.org/licenses/>.

#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::depends(RcppEigen)]]
#include <RcppEigen.h>
using Eigen::ArrayXd;
using Eigen::MatrixXd;
using Eigen::VectorXd;

#include "RZigZag.h"
#include <stdio.h>

VectorXi sample(const unsigned int n, const unsigned int k) {
  // crappy inefficient implementation. see http://stackoverflow.com/questions/33802205
  RNGScope scp; // initialize random number generator
  VectorXi samples(k);
  for (unsigned int i = 0; i < k; ++i) {
    bool found_sample = false;
    int proposed_sample;
    while (!found_sample) {
      proposed_sample = floor(runif(1)(0) * n);
      found_sample = true;
      for (unsigned int j = 0; j < i; ++j)
        if (samples[j] == proposed_sample) {
          found_sample = false;
          break;
        }
    }
    if (found_sample)
      samples[i] = proposed_sample;
  }
  return samples;
}

MatrixXd LogisticMALA(const MatrixXd& dataX, const VectorXi& dataY, const unsigned int n_epochs, const VectorXd& beta0, const double stepsize) {
  const MatrixXd dataXpp(preprocessLogistic(dataX));
  const unsigned int dim = dataXpp.rows();
  const unsigned int n_observations = dataX.cols();
  MatrixXd beta(MatrixXd::Zero(dim,n_epochs));
  VectorXd beta_current(beta0);
  beta.col(0) = beta0;
  const LogisticData data(&dataXpp, &dataY);
  VectorXd grad_current = data.gradient(beta_current);
  VectorXd grad_new(grad_current);
  double potential_current = data.potential(beta_current);
  double potential_new = potential_current;
  VectorXd beta_new(beta_current);
  int count_accepted = 0;
  
  RNGScope scp; // initialize random number generator
  for (unsigned int i = 1; i < n_epochs; ++i) {
    
    VectorXd Z = Rcpp::as<Eigen::VectorXd>(rnorm(dim));
    beta_new = beta_current - (stepsize /2) * grad_current + sqrt(stepsize) * Z;
    grad_new = data.gradient(beta_new);
    potential_new = data.potential(beta_new);
    double q_1 = exp(-1/(2 * stepsize) * (beta_new - beta_current + stepsize/2*grad_current).squaredNorm());
    double q_2 = exp(-1/(2 * stepsize) * (beta_current - beta_new + stepsize/2*grad_new).squaredNorm());
    double accept_prob = exp(potential_current - potential_new) * q_2/q_1;
    
    if (runif(1)(0) <= accept_prob) {
      beta_current = beta_new;
      grad_current = grad_new;
      potential_current = potential_new;
      count_accepted++;
    }
    beta.col(i) = beta_current;
  }
  printf("MALA: Fraction of accepted proposals: %g\n", double(count_accepted)/(n_epochs));  
  return beta;
}



MatrixXd LogisticSGLD(const MatrixXd& dataX, const VectorXi& dataY, const unsigned int n_epochs, const VectorXd& beta0, const unsigned int batchsize, const double stepsize) {
  const MatrixXd dataXpp(preprocessLogistic(dataX));
  const unsigned int dim = dataXpp.rows();
  const unsigned int n_observations = dataX.cols();
  const unsigned int n_batches = floor(n_observations/batchsize);
  MatrixXd beta(MatrixXd::Zero(dim,n_epochs));
  VectorXd beta_current(beta0);
  beta.col(0) = beta0;

  RNGScope scp; // initialize random number generator
  for (unsigned int i = 1; i < n_epochs * n_batches; ++i) {
    if (i % n_batches == 0)
      beta.col(i / n_batches) = beta_current;
    VectorXi sampled(sample(n_observations, batchsize));
    VectorXd stochGradient(VectorXd::Zero(dim));
    for (unsigned int j = 0; j < batchsize; ++j) {
      double val = exp(dataXpp.col(sampled[j]).dot(beta_current));
      stochGradient += n_observations * dataXpp.col(sampled[j]) * (val/(1+val) - dataY(sampled[j]))/batchsize;
    }
    VectorXd Z = Rcpp::as<Eigen::VectorXd>(rnorm(dim));
    beta_current += -stepsize * stochGradient + sqrt(2 * stepsize) * Z;
  }

  return beta;
}

MatrixXd GaussianSGLD(const MatrixXd& V, const MatrixXd& mu, const unsigned int n_epochs, const VectorXd& x0, const unsigned int batchsize, const double stepsize, const unsigned int thinning) {
  const unsigned int dim = V.rows();
  const unsigned int n_observations = mu.cols();
  const unsigned int n_batches = floor(n_observations/batchsize);
  MatrixXd x(MatrixXd::Zero(dim,floor(n_epochs * n_batches / thinning)));
  VectorXd x_current(x0);

  RNGScope scp; // initialize random number generator
  for (unsigned int i = 0; i < n_epochs * n_batches; ++i) {
    if (i % thinning == 0)
      x.col(i / thinning) = x_current;
    VectorXi sampled(sample(n_observations, batchsize));
    VectorXd stochGradient(VectorXd::Zero(dim));
    for (unsigned int j = 0; j < batchsize; ++j) {
      stochGradient += V * (x_current - mu.col(sampled(j)))/batchsize;
    }
    VectorXd Z = Rcpp::as<Eigen::VectorXd>(rnorm(dim));
    x_current += -stepsize * stochGradient + sqrt(2 * stepsize) * Z;
  }
  return x;
}

void ZigZagSkeleton::computeBatchMeans(const unsigned int n_batches) {
  if (n_batches == 0)
    printf("Error: n_batches should be positive.\n");
  const unsigned int n_skeletonPoints = skeletonTimes.rows();
  const unsigned int dim = skeletonPoints.rows();
  const double t_max = skeletonTimes[n_skeletonPoints-1];
  const double batch_length = t_max / n_batches;

  double t0 = skeletonTimes[0];
  VectorXd x0 = skeletonPoints.col(0);

  batchMeans = MatrixXd(dim, n_batches);

  unsigned int batchNr = 0;
  double t_intermediate = batch_length;
  VectorXd currentBatchMean = VectorXd::Zero(dim);

  for (unsigned int i = 1; i < n_skeletonPoints; ++i) {
    double t1 = skeletonTimes[i];
    VectorXd x1 = skeletonPoints.col(i);

    while (batchNr < n_batches - 1 && t1 > t_intermediate) {
      VectorXd x_intermediate = x0 + (t_intermediate - t0) / (t1 - t0) * (x1 - x0);
      batchMeans.col(batchNr) = currentBatchMean + (t_intermediate - t0) * (x_intermediate + x0)/(2 * batch_length);

      // initialize next batch
      currentBatchMean = VectorXd::Zero(dim);
      batchNr++;
      t0 = t_intermediate;
      x0 = x_intermediate;
      t_intermediate = batch_length * (batchNr + 1);
    }
    currentBatchMean += (t1 - t0) * (x1 + x0)/(2 * batch_length);
    t0 = t1;
    x0 = x1;
  }
  batchMeans.col(batchNr) = currentBatchMean;

  computeCovariance();

  MatrixXd meanZeroBatchMeans = batchMeans.colwise() - means;
  asVarEst = batch_length * meanZeroBatchMeans.rowwise().squaredNorm()/(n_batches - 1);
  ESS = (covarianceMatrix.diagonal().array()/asVarEst.array() * t_max).matrix();
}

void ZigZagSkeleton::computeCovariance() {
  const unsigned int n_skeletonPoints = skeletonTimes.rows();
  const unsigned int dim = skeletonPoints.rows();
  const double t_max = skeletonTimes[n_skeletonPoints-1];

  double t0 = skeletonTimes[0];
  VectorXd x0 = skeletonPoints.col(0);
  MatrixXd cov_current = x0 * x0.transpose();

  covarianceMatrix = MatrixXd::Zero(dim, dim);
  means = VectorXd::Zero(dim);

  for (unsigned int i = 1; i < n_skeletonPoints; ++i) {
    double t1 = skeletonTimes[i];
    VectorXd x1 = skeletonPoints.col(i);
    // the following expression equals \int_{t_0}^{t_1} x(t) (x(t))^T d t
    covarianceMatrix += (t1 - t0) * (2 * x0 * x0.transpose() + x0 * x1.transpose() + x1 * x0.transpose() + 2 * x1 * x1.transpose())/(6 * t_max);
    means += (t1 - t0) * (x1 + x0) /(2 * t_max);
    t0 = t1;
    x0 = x1;
  }
  covarianceMatrix -= means * means.transpose();
}


LogisticData::LogisticData(const MatrixXd* dataXptr, const VectorXi* dataYptr) : dataXptr(dataXptr), dataYptr(dataYptr) {
  dim = dataXptr->rows();
  n_observations = dataXptr->cols();
}

double LogisticData::potential(const VectorXd& beta) const {
  double val = 0;
  for (unsigned int j = 0; j < n_observations; ++j) {
    double innerproduct = beta.dot(dataXptr->col(j));
    val += log(1 + exp(innerproduct)) - (*dataYptr)(j) * innerproduct;
  }
  return val;
}

VectorXd LogisticData::gradient(const VectorXd& beta) const {
  VectorXd grad(VectorXd::Zero(dim));
  for (unsigned int j = 0; j < n_observations; ++j) {
    double val = exp(dataXptr->col(j).dot(beta));
    grad += dataXptr->col(j) * (val/(1+val) - (*dataYptr)(j));
  }
  return grad;
}

MatrixXd LogisticData::hessian(const VectorXd& beta) const {
  MatrixXd hess(MatrixXd::Zero(dim,dim));
  for (unsigned int j = 0; j < n_observations; ++j) {
    double innerproduct = beta.dot(dataXptr->col(j));
    hess += (dataXptr->col(j) * dataXptr->col(j).transpose())* exp(innerproduct)/((1+exp(innerproduct)*(1+exp(innerproduct))));
  }
  return hess;
}

void ZigZagSkeleton::LogisticBasic(const MatrixXd& dataX, const VectorXi& dataY, const unsigned int n_epochs, const VectorXd& beta0) {

  const MatrixXd dataXpp(preprocessLogistic(dataX));
  const unsigned int n_components = dataXpp.rows();

  MatrixXd Q(domHessianLogistic(dataXpp));

  VectorXd beta(beta0);
  VectorXd theta(VectorXd::Constant(n_components, 1)); // initialize theta at (+1,...,+1)
  double currentTime = 0;

  const VectorXd b(sqrt(n_components) * Q.rowwise().norm());
  VectorXd derivative_upperbound(n_components);
  VectorXd a(n_components);
  for (unsigned int k = 0; k < n_components; ++k) {
    derivative_upperbound(k) = theta(k) * derivativeLogistic(dataXpp, dataY, beta, k);
    if (derivative_upperbound(k) > 0)
      a(k) = derivative_upperbound(k);
    else
      a(k) = 0;
  }

  unsigned int switches = 0;

  RNGScope scp; // initialize random number generator

  double minTime, simulatedTime;

  int i0;
  skeletonPoints = MatrixXd(n_components,n_epochs);
  skeletonPoints.col(0) = beta;
  skeletonTimes = ArrayXd(n_epochs);

  for (unsigned int step = 1; step < n_epochs; ++step) {
    NumericVector U(runif(n_components));
    i0 = -1;
    for (unsigned int i = 0; i < n_components; ++i) {
      simulatedTime = getRandomTime(a(i), b(i), U(i));
      if (simulatedTime > 0 && (i0 == -1 || simulatedTime < minTime)) {
        i0 = i;
        minTime = simulatedTime;
      }
    }
    if (minTime < 0) {
      printf("Zig zag wandered off to infinity.\n");
      break;
    }
    else {
      currentTime = currentTime + minTime;
      beta = beta + minTime * theta;
      for (unsigned int i = 0; i < n_components; ++i) {
        if (i != i0) {
          derivative_upperbound(i) = derivative_upperbound(i) + b(i) * minTime;
          if (derivative_upperbound(i) > 0)
            a(i) = derivative_upperbound(i);
          else
            a(i) = 0;
        }
      }
      double derivative = derivativeLogistic(dataXpp, dataY, beta, i0);
      double V = runif(1)(0);
      if (V <= theta(i0) * derivative/(a(i0)+b(i0)*minTime)) {
        theta(i0) = -theta(i0);
        ++switches;
      }

      derivative_upperbound(i0) = derivative * theta(i0);
      if (derivative_upperbound(i0) > 0)
        a(i0) = derivative_upperbound(i0);
      else
        a(i0) = 0;

      skeletonTimes(step) = currentTime;
      skeletonPoints.col(step) = beta;
    }
  }
  printf("LogisticBasic: Fraction of accepted switches: %g\n", double(switches)/(n_epochs));
}

void ZigZagSkeleton::LogisticUpperbound(const MatrixXd& dataX, const VectorXi& dataY, const unsigned int n_epochs, const VectorXd& beta0) {

  const MatrixXd dataXpp(preprocessLogistic(dataX));
  const unsigned int n_components = dataXpp.rows();
  const unsigned int n_observations = dataXpp.cols();
  VectorXd beta(beta0);
  VectorXd theta(VectorXd::Constant(n_components, 1)); // initialize theta at (+1,...,+1)
  double currentTime = 0;

  const VectorXd a(n_observations * logisticUpperbound(dataXpp));

  unsigned int switches = 0;

  RNGScope scp; // initialize random number generator

  double minTime, simulatedTime;

  int i0;
  skeletonPoints = MatrixXd(n_components,n_epochs);
  skeletonPoints.col(0) = beta;
  skeletonTimes = ArrayXd(n_epochs);

  for (unsigned int step = 1; step < n_epochs; ++step) {
    NumericVector U(runif(n_components));
    i0 = -1;
    for (unsigned int i = 0; i < n_components; ++i) {
      simulatedTime = getRandomTime(a(i), 0, U(i));
      if (simulatedTime > 0 && (i0 == -1 || simulatedTime < minTime)) {
        i0 = i;
        minTime = simulatedTime;
      }
    }
    if (minTime < 0) {
      printf("Zig zag wandered off to infinity.\n");
      break;
    }
    else {
      currentTime = currentTime + minTime;
      beta = beta + minTime * theta;
      double derivative = derivativeLogistic(dataXpp, dataY, beta, i0);
      double V = runif(1)(0);
      if (V <= theta(i0) * derivative/a(i0)) {
        theta(i0) = -theta(i0);
        ++switches;
      }
      skeletonTimes(step) = currentTime;
      skeletonPoints.col(step) = beta;
    }
  }
  printf("LogisticUpperbound: Fraction of accepted switches: %g\n", double(switches)/(n_epochs));
}

void ZigZagSkeleton::LogisticSubsampling(const MatrixXd& dataX, const VectorXi& dataY, const unsigned int n_epochs, const VectorXd& beta0) {

  const MatrixXd dataXpp(preprocessLogistic(dataX));
  const unsigned int dim = dataXpp.rows();
  const unsigned int n_observations = dataXpp.cols();

  VectorXd beta(beta0);
  VectorXd theta(VectorXd::Constant(dim,1)); // initialize theta at (+1,...,+1)
  double currentTime = 0;
  VectorXd upperbound(n_observations * logisticUpperbound(dataXpp));

  RNGScope scp; // initialize random number generator

  double minTime, simulatedTime;

  unsigned int max_switches = n_epochs;

  MatrixXd skeletonPointsTemp = MatrixXd(dim, max_switches);
  skeletonPointsTemp.col(0) = beta;
  ArrayXd skeletonTimesTemp = ArrayXd(max_switches);
  skeletonTimesTemp[0] = currentTime;


  unsigned int i0;
  unsigned int switches = 0;
  for (unsigned int step = 1; step < n_epochs * n_observations; ++step) {
    for (unsigned int i = 0; i < dim; ++i) {
      simulatedTime = rexp(1, upperbound(i))(0);
      if (i == 0 || simulatedTime < minTime) {
        i0 = i;
        minTime = simulatedTime;
      }
    }
    currentTime = currentTime + minTime;
    beta = beta + minTime * theta;
    unsigned int J = floor(n_observations*runif(1)(0)); // randomly select observation
    double derivative = n_observations * dataXpp(i0,J) * (1.0/(1.0+exp(-dataXpp.col(J).dot(beta))) - dataY(J));
    double V = runif(1)(0);
    if (derivative > upperbound(i0)) {
      printf("LogisticSubsampling:: Error: derivative larger than its supposed upper bound.\n");
      printf("  Upper bound: %g, actual derivative: %g.\n", upperbound(i0), derivative);
      printf("  Index: %d, Beta(0): %g, Beta(1): %g\n", i0, beta(0), beta(1));
      break;
    }
    if (V <= theta(i0) * derivative/upperbound(i0)) {
      theta(i0) = -theta(i0);
      ++switches;
      if (switches >= max_switches) {
        max_switches *= 2;
//        printf("Resizing to size %d...\n", max_switches);
        skeletonTimesTemp.conservativeResize(max_switches);
        skeletonPointsTemp.conservativeResize(dim, max_switches);
      }
      skeletonTimesTemp[switches] = currentTime;
      skeletonPointsTemp.col(switches) = beta;
    }
  }
  printf("LogisticSubSampling: Fraction of accepted switches: %g\n", double(switches)/(n_epochs * n_observations));
  skeletonTimes = skeletonTimesTemp.head(switches + 1);
  skeletonPoints = skeletonPointsTemp.leftCols(switches + 1);
}

void ZigZagSkeleton::LogisticControlVariates(const MatrixXd& dataX, const VectorXi& dataY, const unsigned int n_epochs, const VectorXd& beta0) {

  const MatrixXd dataXpp(preprocessLogistic(dataX));
  LogisticData data(&dataXpp, &dataY);
  const unsigned int dim = dataXpp.rows();
  const unsigned int n_observations = dataXpp.cols();
  VectorXd beta(beta0);
  const double precision = 1e-10;
  const unsigned int max_iter = 1e2;
  newtonLogistic(data, beta, precision, max_iter);
  mode = beta;
  beta = beta0;


  VectorXd theta(VectorXd::Constant(dim,1)); // initialize theta at (+1,...,+1)
  double currentTime = 0;
  const VectorXd uniformBound(cvBound(dataXpp) * n_observations);
  const VectorXd b(sqrt(dim) * uniformBound);
  VectorXd a((beta-mode).norm() * uniformBound);

  RNGScope scp; // initialize random number generator

  double minTime, simulatedTime;

  unsigned int max_switches = n_epochs;

  MatrixXd skeletonPointsTemp = MatrixXd(dim, max_switches);
  skeletonPointsTemp.col(0) = beta;
  ArrayXd skeletonTimesTemp = ArrayXd(max_switches);
  skeletonTimesTemp[0] = currentTime;

  int i0;
  unsigned int switches = 0;
  for (unsigned int step = 1; step < n_epochs * n_observations; ++step) {
    NumericVector U(runif(dim));
    i0 = -1;
    for (unsigned int i = 0; i < dim; ++i) {
      simulatedTime = getRandomTime(a(i), b(i), U(i));
      if (simulatedTime > 0 && (i0 == -1 || simulatedTime < minTime)) {
        i0 = i;
        minTime = simulatedTime;
      }
    }
    if (minTime < 0) {
      // this means that we simulated T = inf
      printf("Zig zag wandered off to infinity.\n");
      break;
    }
    else {
      currentTime = currentTime + minTime;
      beta = beta + minTime * theta;
      unsigned int J = floor(n_observations*runif(1)(0)); // randomly select observation
      double switch_rate = theta(i0) * n_observations * dataXpp(i0,J) * (1.0/(1.0+exp(-dataXpp.col(J).dot(beta)))-1.0/(1.0+exp(-dataXpp.col(J).dot(mode))));
      double simulated_rate = a(i0) + b(i0) * minTime;
      if (switch_rate > simulated_rate) {
        printf("LogisticControlVariates:: Error: switch rate larger than its supposed upper bound.\n");
        printf("  Step: %d, Upper bound: %g, actual switch rate: %g.\n", step, simulated_rate, switch_rate);
        printf("  Index: %d, Beta(0): %g, Beta(1): %g\n", i0, beta(0), beta(1));
        break;
      }
      double V = runif(1)(0);
      if (V <= switch_rate/simulated_rate) {
        theta(i0)=-theta(i0);
        ++switches;
        if (switches >= max_switches) {
          max_switches *= 2;
//          printf("Resizing to size %d...\n", max_switches);
          skeletonTimesTemp.conservativeResize(max_switches);
          skeletonPointsTemp.conservativeResize(dim, max_switches);
        }
        skeletonTimesTemp[switches] = currentTime;
        skeletonPointsTemp.col(switches) = beta;
      }
      a = (beta-mode).norm() * uniformBound;
    }
  }
  printf("LogisticControlVariates: Fraction of accepted switches: %g\n", double(switches)/(n_epochs * n_observations));
  skeletonTimes = skeletonTimesTemp.head(switches + 1);
  skeletonPoints = skeletonPointsTemp.leftCols(switches + 1);
}

void ZigZagSkeleton::GaussianBasic(const MatrixXd& V, const VectorXd& mu, const unsigned int n_steps, const VectorXd& x0) {
  // Gaussian skeleton
  // input: V precision matrix (inverse covariance), mu mean, x0 initial condition, n_steps number of switches
  // invariant: w = V theta, z = V (x-mu)

  const unsigned int dim = V.cols();
  VectorXd x(x0);
  VectorXd theta = VectorXd::Constant(dim, 1); // initialize theta at (+1,...,+1)
  ArrayXd w(V * theta), z(V * (x-mu));
  ArrayXd a(theta.array() * z), b(theta.array() * w); // convert to array for pointwise multiplication

  RNGScope scp; // initialize random number generator

  double minTime, simulatedTime;
  int i0;
  skeletonPoints = MatrixXd(dim,n_steps);
  skeletonPoints.col(0) = x0;
  skeletonTimes = ArrayXd(n_steps);
  double currentTime = 0;

  for (unsigned int step = 1; step < n_steps; ++step) {
    NumericVector U(runif(dim));
    i0 = -1;
    for (unsigned int i = 0; i < dim; ++i) {
      simulatedTime = getRandomTime(a(i), b(i), U(i));
      if (simulatedTime > 0 && (i0 == -1 || simulatedTime < minTime)) {
        i0 = i;
        minTime = simulatedTime;
      }
    }
    if (minTime < 0) {
      // this means that we simulated T = inf
      printf("Zig zag wandered off to infinity.\n");
      break;
    }
    else {
      currentTime = currentTime + minTime;
      x = x + minTime * theta;
      theta(i0) = -theta(i0);
      z = z + w * minTime; // preserve invariant  z = V (x-mu)
      w = w + 2 * theta(i0) * V.col(i0).array(); // preserve invariant w = V theta
      a = theta.array() * z;
      b = theta.array() * w;
      skeletonTimes(step) = currentTime;
      skeletonPoints.col(step) = x;
    }
  }
}

void ZigZagSkeleton::GaussianControlVariates(const MatrixXd& V, const MatrixXd& mu, const unsigned int n_epochs, const VectorXd& x0, const unsigned int p, const double c) {
  // Gaussian skeleton
  // purely for academic purposes -- for a Gaussian, GaussianBasic is more efficient!
  // input: V precision matrix (inverse covariance), columns of mu: different observations for mu, x0 initial condition, n_steps number of switches
  // assume potential of form Psi(x) = 1/(2 n) sum_{j=1}^n (x - mu^j)^T V (x - mu^j)
  // p determines which norm to use in computational bounds, currently only p = 0, 1, 2 are supported, with p = 0 meaning infinity
  // a value of c smaller than one means that we want to base our pre-computed MAP estimate on a sub-sample of relative size c
  const unsigned int dim = V.rows();
  const unsigned int n_observations = mu.cols();
  // in next statement, compute rowwise *dual* norm
  VectorXd C;
  if (p == 0)
    C = V.cwiseAbs().rowwise().sum();
  else if (p == 1)
    C = V.cwiseAbs().rowwise().maxCoeff();
  else // assume p == 2
    C = V.rowwise().norm();
  const unsigned int m = ceil(c*n_observations);
  const VectorXd x_star(mu.leftCols(m).rowwise().sum()/m); // sampling without replacement, assuming columns exchangeable, so taking first columns
  const VectorXd posteriormean(mu.rowwise().sum()/n_observations);
  const VectorXd gradPsi_x_star(V*(x_star - posteriormean));
  VectorXd theta = VectorXd::Constant(dim, 1); // initialize theta at (+1,...,+1)
  VectorXd x(x0);
  VectorXd a;
  if (p == 0)
    a = gradPsi_x_star.cwiseProduct(theta).cwiseMax(0) + C * (x - x_star).cwiseAbs().maxCoeff();
  else if (p == 1)
    a = gradPsi_x_star.cwiseProduct(theta).cwiseMax(0) + C * (x - x_star).cwiseAbs().sum();
  else // assume p == 2
    a = gradPsi_x_star.cwiseProduct(theta).cwiseMax(0) + C * (x - x_star).norm();
//  if (p == 0)
//   a = gradPsi_x_star.cwiseAbs() + C * (x - x_star).cwiseAbs().maxCoeff();
//  else if (p == 1)
//    a = gradPsi_x_star.cwiseAbs() + C * (x - x_star).cwiseAbs().sum();
//  else // assume p == 2
//    a = gradPsi_x_star.cwiseAbs() + C * (x - x_star).norm();
  const VectorXd b = C * (p == 0 ? 1 : pow(dim,1/p));

  unsigned int max_switches = n_epochs;
  MatrixXd skeletonPointsTemp = MatrixXd(dim, max_switches);
  skeletonPointsTemp.col(0) = x;
  ArrayXd skeletonTimesTemp = ArrayXd(max_switches);
  skeletonTimesTemp[0] = 0;
  unsigned int switches = 0;

  RNGScope scp; // initialize random number generator

  double minTime, simulatedTime;
  int i0;
  double currentTime = 0;

  for (unsigned int step = 1; step < n_epochs * n_observations; ++step) {
    NumericVector U(runif(dim));
    i0 = -1;
    for (unsigned int i = 0; i < dim; ++i) {
      simulatedTime = getRandomTime(a(i), b(i), U(i));
      if (simulatedTime > 0 && (i0 == -1 || simulatedTime < minTime)) {
        i0 = i;
        minTime = simulatedTime;
      }
    }
    if (minTime < 0) {
      printf("ZigZag::GaussianControlVariates error: wandered off to infinity.\n");
      break;
    }
    else {
      currentTime = currentTime + minTime;
      x = x + minTime * theta;
      double switch_rate = theta(i0) * V.row(i0).dot(x - posteriormean);
      double simulated_rate = a(i0) + b(i0) * minTime;
      if (switch_rate > simulated_rate + 1e-8) {
        printf("ZigZag::GaussianControlVariates error: switch rate larger than its supposed upper bound.\n");
        printf("  Step: %d, Upper bound: %g, actual switch rate: %g.\n", step, simulated_rate, switch_rate);
        printf("  Index: %d, x(0): %g\n", i0, x(0));
        break;
      }
      double Z = runif(1)(0);
      if (Z <= switch_rate/simulated_rate) {
        theta(i0)=-theta(i0);
        ++switches;
        if (switches >= max_switches) {
          max_switches *= 2;
          skeletonTimesTemp.conservativeResize(max_switches);
          skeletonPointsTemp.conservativeResize(dim, max_switches);
        }
        skeletonTimesTemp[switches] = currentTime;
        skeletonPointsTemp.col(switches) = x;
      }
      if (p == 0)
	a = gradPsi_x_star.cwiseProduct(theta).cwiseMax(0) + C * (x - x_star).cwiseAbs().maxCoeff();
      else if (p == 1)
	a = gradPsi_x_star.cwiseProduct(theta).cwiseMax(0) + C * (x - x_star).cwiseAbs().sum();
      else // assume p == 2
	a = gradPsi_x_star.cwiseProduct(theta).cwiseMax(0) + C * (x - x_star).norm();
//      if (p == 0)
//	a = gradPsi_x_star.cwiseAbs() + C * (x - x_star).cwiseAbs().maxCoeff();
//     else if (p == 1)
//	a = gradPsi_x_star.cwiseAbs() + C * (x - x_star).cwiseAbs().sum();
//      else // assume p == 2
//	a = gradPsi_x_star.cwiseAbs() + C * (x - x_star).norm();
    }
  }
  printf("GaussianControlVariates: Fraction of accepted switches: %g\n", double(switches)/(n_epochs * n_observations));
  skeletonTimes = skeletonTimesTemp.head(switches + 1);
  skeletonPoints = skeletonPointsTemp.leftCols(switches + 1);
}

List ZigZagSkeleton::toR() {
  // output: R list consisting of skeletonTimes and skeletonPoints, and if samples are collected these too
  return List::create(Named("skeletonTimes") = skeletonTimes, Named("skeletonPoints") = skeletonPoints, Named("samples") = samples, Named("mode") = mode, Named("batchMeans") = batchMeans, Named("means") = means, Named("covariance") = covarianceMatrix, Named("asVarEst") = asVarEst, Named("ESS") = ESS);
}

Eigen::MatrixXd ZigZagSkeleton::sample(const unsigned int n_samples) {

  const unsigned int n_steps = skeletonTimes.size();
  const unsigned int dim = skeletonPoints.rows();
  const double t_max = skeletonTimes(n_steps-1);
  const double dt = t_max / (n_samples+1);

  double t_current = dt;
  double t0 = skeletonTimes(0);
  double t1;
  VectorXd x0(skeletonPoints.col(0));
  VectorXd x1(dim);
  samples = MatrixXd(dim, n_samples);
  unsigned int n_sampled = 0; // number of samples collected

  for (unsigned int i = 1; i < n_steps; ++i) {
    x1 = skeletonPoints.col(i);
    t1 = skeletonTimes(i);
    while (t_current < t1 && n_sampled < n_samples) {
      samples.col(n_sampled) = x0 + (x1-x0) * (t_current - t0)/(t1-t0);
      ++n_sampled;
      t_current = t_current + dt;
    }
    x0 = x1;
    t0 = t1;
  }

  return samples;
}

// [[Rcpp::export]]
List ZigZagLogistic(const Eigen::MatrixXd dataX, const Eigen::VectorXi dataY, const unsigned int n_epochs, const bool subsampling, const bool controlvariates, const Eigen::VectorXd beta0, const unsigned int n_samples = 0, const unsigned int n_batches = 0, bool computeCovariance = false, bool upperbound = false) {
  ZigZagSkeleton skeleton;
  if (controlvariates)
    skeleton.LogisticControlVariates(dataX, dataY, n_epochs, beta0);
  else if (subsampling)
    skeleton.LogisticSubsampling(dataX, dataY, n_epochs, beta0);
  else if (upperbound)
    skeleton.LogisticUpperbound(dataX, dataY, n_epochs, beta0);
  else
    skeleton.LogisticBasic(dataX, dataY, n_epochs, beta0);
  if (n_samples > 0)
    skeleton.sample(n_samples);
  if (n_batches > 0)
    skeleton.computeBatchMeans(n_batches);
  if (computeCovariance)
    skeleton.computeCovariance();
  return skeleton.toR();
}

// [[Rcpp::export]]
List SGLDLogistic(const Eigen::MatrixXd& dataX, const Eigen::VectorXi& dataY, const unsigned int n_epochs, const Eigen::VectorXd& beta0, const unsigned int batchsize, const double stepsize) {
  return List::create(Named("beta") = LogisticSGLD(dataX, dataY, n_epochs, beta0, batchsize, stepsize));
}

// [[Rcpp::export]]
List MALALogistic(const Eigen::MatrixXd& dataX, const Eigen::VectorXi& dataY, const unsigned int n_epochs, const Eigen::VectorXd& beta0, const double stepsize) {
  return List::create(Named("beta") = LogisticMALA(dataX, dataY, n_epochs, beta0, stepsize));
}


// [[Rcpp::export]]
List ZigZagGaussian(const Eigen::MatrixXd V, const Eigen::MatrixXd mu, const unsigned int n_epochs, const Eigen::VectorXd x0, const bool controlvariates=true, const unsigned int n_samples=0, const unsigned int n_batches=0, bool computeCovariance=false, const double c = 1) {
  ZigZagSkeleton skeleton;
  if (controlvariates)
    skeleton.GaussianControlVariates(V, mu, n_epochs, x0, 2, c);
  else
    skeleton.GaussianBasic(V, mu, n_epochs, x0);
  if (n_samples > 0)
    skeleton.sample(n_samples);
  if (n_batches > 0)
    skeleton.computeBatchMeans(n_batches);
  if (computeCovariance)
    skeleton.computeCovariance();
  return skeleton.toR();
}

// [[Rcpp::export]]
List SGLDGaussian(const Eigen::MatrixXd& V, const Eigen::MatrixXd& mu, const unsigned int n_epochs, const Eigen::VectorXd& x0, const unsigned int batchsize, const double stepsize, const unsigned int thinning = 1) {
  return List::create(Named("x") = GaussianSGLD(V, mu, n_epochs, x0, batchsize, stepsize, thinning));
}



double getRandomTime(double a, double b, double u) {
  // NOTE: Return value -1 indicates +Inf!
  if (b > 0) {
    if (a < 0)
      return -a/b + getRandomTime(0, b, u);
    else       // a >= 0
      return -a/b + sqrt(a*a/(b * b) - 2 * log(u)/b);
  }
  else if (b == 0) {
    if (a > 0)
      return -log(u)/a;
    else
      return -1; // infinity
  }
  else {
    // b  < 0
    if (a <= 0)
      return -1; // infinity
    else {
      // a > 0
      double t1 = -a/b;
      if (-log(u) <= a * t1 + b * t1 * t1/2)
        return -a/b - sqrt(a*a/(b * b) - 2 * log(u)/b);
      else
        return -1;
    }
  }
}

MatrixXd preprocessLogistic(const MatrixXd& dataX) {
  const unsigned int n_observations = dataX.cols();
  const unsigned int n_components = dataX.rows() + 1; // we will add a row of constant, so for practical purposes +1

  // re-center the data around the origin. TODO: How does this affect the results?
  VectorXd meanX = dataX.rowwise().sum()/n_observations;
  MatrixXd dataXpp(n_components, n_observations);
  dataXpp.topRows(1) = MatrixXd::Constant(1, n_observations,1);
  for (unsigned int i = 0; i < n_observations; ++i)
    dataXpp.bottomRows(n_components - 1).col(i) = dataX.col(i) - meanX;

  return dataXpp;
}

MatrixXd domHessianLogistic(const MatrixXd& dataX) {
  const unsigned int n_observations = dataX.cols();
  const unsigned int dim = dataX.rows();

  MatrixXd domHessian(MatrixXd::Zero(dim,dim));
  for (unsigned int j = 0; j < n_observations; ++j) {
    domHessian += 0.25 * (dataX.col(j) * dataX.col(j).transpose());
  }
  return domHessian;
}


VectorXd cvBound(const MatrixXd& dataX) {
  const unsigned int dim = dataX.rows();
  const unsigned int n_observations = dataX.cols();
  const VectorXd norms (dataX.colwise().norm());
  VectorXd bounds(dim);

  for (unsigned int k =0; k < dim; ++k) {
    bounds(k) = 0.0;
    for (unsigned int l = 0; l < n_observations; ++l) {
      double val = fabs(dataX(k,l) * norms(l));
      if (bounds(k) < val)
        bounds(k) = val;
    }
  }
  return 0.25 * bounds;
}

double derivativeLogistic(const MatrixXd& dataX, const VectorXi& dataY, const VectorXd& beta, unsigned int k) {
// compute dPsi/dbeta_k for logistic regression

  const unsigned int n_observations = dataX.cols();
  const unsigned int n_components = dataX.rows();
  double derivative = 0;

  for (unsigned int j = 0; j < n_observations; ++j) {
    double val = exp(dataX.col(j).dot(beta));
    derivative += dataX(k,j) * (val/(1+val) - dataY(j));
  }
  return derivative;
}

VectorXd logisticUpperbound(const MatrixXd& dataX) {
  return dataX.array().abs().rowwise().maxCoeff();
}

double newtonLogistic(const LogisticData& data, VectorXd& beta, double precision, const unsigned int max_iter) {
  VectorXd grad(data.gradient(beta));
  unsigned int i = 0;
  for (i = 0; i < max_iter; ++i) {
    if (grad.norm() < precision)
      break;
    MatrixXd H(data.hessian(beta));
    beta -= H.ldlt().solve(grad);
    grad = data.gradient(beta);
  }
  if (i == max_iter) {
    printf("Warning: Maximum number of iterations (%d) reached without convergence in Newton's method.\n", max_iter);
    printf("Norm of gradient: %g.\n", grad.norm());
  }
  else
    printf("Newton: Converged to local minimum in %d iterations.\n", i);
  return data.potential(beta);
}
